package SeleniumDemo;

public class demo {
	public static void main(String args[]){
	     Test s1 = new Test();
	     s1.showData();
	     Test s2 = new Test();
	     s2.showData();
	     
	  }
	}

	class Test {
	char a; //initialized to zero
	static char b; //initialized to zero only when class is loaded not for each object created.

	  Test(){
	   //Constructor incrementing static variable b
	   b++;
	  }

	   public void showData(){
	      System.out.println("Value of a = "+a);
	      System.out.println("Value of b = "+b);
	   }
	//public static void increment(){
	//a++;
	//}

	}

