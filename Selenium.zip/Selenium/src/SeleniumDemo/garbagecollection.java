package SeleniumDemo;

public class garbagecollection {

	public static void main (String args[]) {

	garbagecollection s1=new garbagecollection();  
	garbagecollection s2=new garbagecollection();  
	System.out.println("print the garbage collected");
	  s1=null;  
	  s2=null;  
	  System.gc();  
	}
}