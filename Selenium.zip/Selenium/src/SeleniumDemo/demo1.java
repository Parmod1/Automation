package SeleniumDemo;

public class demo1 {

	static int a = 5;
	static int b = 17;
	static int c = 10;
	 
	

	public static void main(String args[]) {

		int d= 20;// non-static variables 
		int e= 25; // non-static(instance) variables.
		
		System.out.println("Value of a = " + a);
		System.out.println("Value of b = " + b);
		System.out.println("value of c = " + c);
		System.out.println("value of d = " + d);
		System.out.println("value of e = " + e);

	}
	
	}
