package SeleniumDemo;

import java.util.ArrayList;

public class arraylist {
	
	public static void main (String args[]) {

	ArrayList <String> a1 = new ArrayList<String> ();
	
	  a1.add("Ram1");
	  a1.add("Ram2");
	  a1.add ("Ram3");
	  a1.add("Ram3");
	  
	  System.out.println(a1);
	  
	}
}
